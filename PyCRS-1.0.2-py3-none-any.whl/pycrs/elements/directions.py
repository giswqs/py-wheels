
class North:
    proj4 = "n"
    ogc_wkt = "NORTH"
    esri_wkt = "NORTH"

class East:
    proj4 = "e"
    ogc_wkt = "EAST"
    esri_wkt = "EAST"

class South:
    proj4 = "s"
    ogc_wkt = "SOUTH"
    esri_wkt = "SOUTH"

class West:
    proj4 = "w"
    ogc_wkt = "WEST"
    esri_wkt = "WEST"

class Up:
    proj4 = "u"
    ogc_wkt = "UP"
    esri_wkt = "UP"

class Down:
    proj4 = "d"
    ogc_wkt = "DOWN"
    esri_wkt = "DOWN"
    
